
package agentes;

import Mensaje.Mensajes;
import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;

public class Agente4 extends Agent {

    @Override
    protected void setup() {
        addBehaviour(new Comportamiento());
    }

    class Comportamiento extends CyclicBehaviour {

        @Override
        public void action() {

           

            // Recibir mensaje de agente 2
            ACLMessage aclMSJ = blockingReceive();
            System.out.println(aclMSJ);

            // Recibir mensaje de agente 3
            ACLMessage aclMSJ2 = blockingReceive();
            System.out.println(aclMSJ2);

             // Enviar mensaje a agente 5
             Mensajes.send_msj(ACLMessage.INFORM, "Ag5", getAgent(),
             "cod-4-5", "Hola mi nombre es " + getName());

            
        }

    }

}
