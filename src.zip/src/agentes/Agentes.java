
package agentes;

import Contenedor.Contenedor;

public class Agentes {
    public static void main(String[] args) {
        new Contenedor().configurarContenedor();
    }

}
