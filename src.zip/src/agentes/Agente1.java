
package agentes;

import Mensaje.Mensajes;
import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;

public class Agente1 extends Agent {

    @Override
    protected void setup() {
        addBehaviour(new Comportamiento());
    }

    class Comportamiento extends CyclicBehaviour {

        @Override
        public void action() {

            // Enviar mensaje a agente 2
            Mensajes.send_msj(ACLMessage.INFORM, "Ag2", getAgent(),
                    "cod-1-2", "Hola mi nombre es " + getName());

            // Recibir mensaje de agente 5
            ACLMessage aclMSJ = blockingReceive();
            System.out.println(aclMSJ);

            doDelete();

        }

    }

}
