
package agentes;

import Mensaje.Mensajes;
import jade.core.Agent;

import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;

public class Agente2 extends Agent {

    @Override
    protected void setup() {
        addBehaviour(new Comportamiento());
    }

    class Comportamiento extends CyclicBehaviour {

        @Override
        public void action() {

            // Recibir mensaje de Agente1
            ACLMessage aclMSJ = blockingReceive();
            System.out.println(aclMSJ);
            
            // Enviar mensaje al agente 3
            Mensajes.send_msj(ACLMessage.INFORM, "Ag3", getAgent(),
                    "cod-2-3", "Hola mi nombre es " + getName());
            // Enviar mensaje a Agente 4
            Mensajes.send_msj(ACLMessage.INFORM, "Ag4", getAgent(),
                    "cod-2-4", "Hola mi nombre es " + getName());

        }

    }

}
