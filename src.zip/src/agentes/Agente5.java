
package agentes;

import Mensaje.Mensajes;
import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;

public class Agente5 extends Agent {

    @Override
    protected void setup() {
        addBehaviour(new Comportamiento());
    }

    class Comportamiento extends CyclicBehaviour {

        @Override
        public void action() {

            // Recibir mensaje de agente 4
            ACLMessage aclMSJ = blockingReceive();
            System.out.println(aclMSJ);

            // Enviar mensaje a agente 1
            Mensajes.send_msj(ACLMessage.INFORM, "Ag1", getAgent(),
                    "cod-5-1", "Hola mi nombre es " + getName());

        }

    }

}
