
package Contenedor;

import jade.core.Profile;
import jade.core.ProfileImpl;
import jade.wrapper.AgentContainer;
import jade.wrapper.StaleProxyException;
import java.util.logging.Level;
import java.util.logging.Logger;

import agentes.Agente1;
import agentes.Agente2;
import agentes.Agente3;
import agentes.Agente4;
import agentes.Agente5;

public class Contenedor {
    AgentContainer agentContainer;

    public void configurarContenedor() {
        jade.core.Runtime runtime = jade.core.Runtime.instance();
        Profile profile = new ProfileImpl(null, 1099, null);
        agentContainer = runtime.createMainContainer(profile);
        agregarAgentes();
    }

    private void agregarAgentes() {
        try {
            agentContainer.createNewAgent("Ag5", Agente5.class.getName(), null).start();
            agentContainer.createNewAgent("Ag4", Agente4.class.getName(), null).start();
            agentContainer.createNewAgent("Ag3", Agente3.class.getName(), null).start();
            agentContainer.createNewAgent("Ag2", Agente2.class.getName(), null).start();
            agentContainer.createNewAgent("Ag1", Agente1.class.getName(), null).start();

        } catch (StaleProxyException ex) {
            Logger.getLogger(Contenedor.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
